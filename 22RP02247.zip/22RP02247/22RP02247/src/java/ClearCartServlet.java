import java.io.*;
import jakarta.servlet.*;
import jakarta.servlet.http.*;

public class ClearCartServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Cookie cartCookie = new Cookie("cart", "");
        cartCookie.setMaxAge(0); // This will delete the cookie
        response.addCookie(cartCookie);

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h2>Cart Cleared</h2>");
        out.println("<p>Your shopping cart has been cleared.</p>");
        out.println("<a href='index.html'><button type=\"button\">Back to main page </button></a>");
        out.println("</body></html>");
    }
}